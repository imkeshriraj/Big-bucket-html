<?php

include './header.php';

?>

    <!-- -----------Account page------ -->
    <div class="account-page">
        <div class="container contact">
            <div class="row">

                <div class="col-3">
                    <h1>Contact US</h1>
                    <form>
                        <label>User Name</label>
                        <input type="text" placeholder="Enter Your Name">


                        <label>Email address</label>
                        <input type="email" placeholder="Enter E-mail">


                        <label>Email your Phone Number</label>
                        <input type="tel" placeholder="Phone Number">

                        <label>Detail</label><br>
                        <textarea style="height: 70px;"></textarea>


                        <button type="submit" class="btn">Submit</button>

                    </form>
                </div>
                <div class="col-1">
                    <img src="./img/186023-removebg-preview.png">
                </div>
            </div>
        </div>
    </div>
    <?php
include './footer.php';
?>






   