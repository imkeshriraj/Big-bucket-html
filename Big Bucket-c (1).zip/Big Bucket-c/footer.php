<div class="footer ">
        <div class="container ">
            <div class="row ">
                <div class="footer-col-1 ">
                    <h3>Download Our App</h3>
                    <p>Lorem ipsum dolor sit amet consectetura</p>
                    <div class="app-logo ">
                        <img src="./img/product/play-store.png ">
                        <img src="./img/product/app-store.png ">
                    </div>

                </div>
                <div class="footer-col-2 ">
                    <img src="./img/product/logo-white.png">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illo tenetur labore natus laudantium! Quas?</p>

                </div>
                <div class="footer-col-3 ">
                    <h3>Useful LInks</h3>

                    <ul>

                        <li>Coupons</li>
                        <li>Blog POst</li>
                        <li>Return PLoicy</li>
                        <li>Join Affilate</li>
                    </ul>
                </div>
                <div class="footer-col-4 ">
                    <h3>Follow Us</h3>

                    <ul>

                        <li>Facebook</li>
                        <li>Twittert</li>
                        <li>Instagram</li>
                        <li>Youtube</li>
                    </ul>
                </div>

            </div>
            <hr>

            <p class="copyright ">Copyight2020 -lorem Epsum</p>
        </div>
    </div>







    <!-- -----------------------js for menu Toggle---->
    <script>
        var menu = document.getElementById('menuItems');
        menu.style.maxHeight = "0px";

        function menutoggle() {
            console.log("click")
            if (menu.style.maxHeight == "0px") {
                menu.style.maxHeight = "200px"
            } else {
                menu.style.maxHeight = "0px"
            }
        }
    </script>




  